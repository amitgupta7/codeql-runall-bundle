
from abc import abstractmethod

class Pass(object):

    @abstractmethod
    def extract(self, module, writer):
        pass
